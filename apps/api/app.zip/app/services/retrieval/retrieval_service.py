from app.db.models import DocumentChunk

from app.repositories.document_chunk_repository import (
    DocumentChunkRepository,
)

from app.services.ai.embeddings import (
    EmbeddingService,
)


class RetrievalService:

    def __init__(
        self,
        chunk_repository: DocumentChunkRepository,
        embedding_service: EmbeddingService,
    ):
        self.chunk_repository = chunk_repository
        self.embedding_service = embedding_service

    async def retrieve(
        self,
        query: str,
        user_id: int,
        top_k: int = 5,
    ) -> list[DocumentChunk]:

        embedding = await self.embedding_service.embed(
            query,
        )

        return await self.chunk_repository.semantic_search(
            embedding=embedding,
            user_id=user_id,
            limit=top_k,
        )