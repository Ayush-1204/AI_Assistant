from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.db.models import Document, DocumentChunk, DocumentStatus


class DocumentChunkRepository:

    def __init__(
        self,
        db: AsyncSession,
    ):
        self.db = db

    async def create(
        self,
        chunk: DocumentChunk,
    ) -> DocumentChunk:

        self.db.add(chunk)

        await self.db.commit()

        await self.db.refresh(chunk)

        return chunk

    async def create_many(
        self,
        chunks: list[DocumentChunk],
    ):

        self.db.add_all(chunks)

        await self.db.commit()

    async def list_by_document(
        self,
        document_id: int,
    ) -> list[DocumentChunk]:

        result = await self.db.execute(
            select(DocumentChunk)
            .where(
                DocumentChunk.document_id == document_id
            )
            .order_by(
                DocumentChunk.chunk_index.asc()
            )
        )

        return list(result.scalars().all())

    async def delete_by_document(
        self,
        document_id: int,
    ):

        chunks = await self.list_by_document(
            document_id,
        )

        for chunk in chunks:
            await self.db.delete(chunk)

        await self.db.commit()

    async def update(
        self,
        chunk: DocumentChunk,
    ) -> DocumentChunk:

        self.db.add(chunk)

        await self.db.commit()

        await self.db.refresh(chunk)

        return chunk
    
    async def update_many(
        self,
        chunks: list[DocumentChunk],
    ) -> None:

        self.db.add_all(chunks)

        await self.db.commit()

    async def semantic_search(
        self,
        embedding: list[float],
        user_id: int,
        limit: int = 5,
    ):

        stmt = (
            select(DocumentChunk)
            .join(Document)
            .where(
                Document.user_id == user_id,
                Document.status == DocumentStatus.READY,
            )
            .order_by(
                DocumentChunk.embedding.cosine_distance(
                    embedding,
                )
            )
            .limit(limit)
            .options(
                selectinload(DocumentChunk.document)
            )
        )

        result = await self.db.execute(stmt)

        return result.scalars().all()