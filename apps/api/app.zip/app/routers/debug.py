from fastapi import APIRouter, Depends

from app.dependencies import (
    get_current_user,
    get_retrieval_service,
)

from app.services.retrieval import RetrievalService

router = APIRouter(
    prefix="/debug",
    tags=["Debug"],
)


@router.post("/search")
async def debug_search(

    query: str,

    current_user=Depends(
        get_current_user,
    ),

    retrieval: RetrievalService = Depends(
        get_retrieval_service,
    ),

):

    chunks = await retrieval.retrieve(
        query=query,
        user_id=current_user.id,
    )

    return [
        {
            "document": c.document.title,
            "chunk": c.chunk_index,
            "tokens": c.token_count,
            "content": c.content[:300],
        }
        for c in chunks
    ]